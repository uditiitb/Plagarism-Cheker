#include "structures.hpp"
#include <vector>
#include <queue>
#include <memory>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <atomic>
#include <unordered_map>
#include <cmath>
#include "../tokenizer.hpp"
// -----------------------------------------------------------------------------

// You are free to add any STL includes above this comment, below the --line--.
// DO NOT add "using namespace std;" or include any other files/libraries.
// Also DO NOT add the include "bits/stdc++.h"

// OPTIONAL: Add your helper functions and classes here


class plagiarism_checker_t {
    // You should NOT modify the public interface of this class.
public:
    plagiarism_checker_t(size_t num_threads = std::thread::hardware_concurrency());
    plagiarism_checker_t(std::vector<std::shared_ptr<submission_t>> __submissions, size_t num_threads = std::thread::hardware_concurrency());
    ~plagiarism_checker_t(void);
    void add_submission(std::shared_ptr<submission_t> __submission);

protected:
    // TODO: Add members and function signatures here
    std::vector<std::pair<std::shared_ptr<submission_t>, std::chrono::system_clock::time_point>> submissions;
    std::queue<std::pair<std::shared_ptr<submission_t>, std::chrono::system_clock::time_point>> submission_queue;
    std::mutex queue_mutex;
    std::mutex submission_mutex;
    std::condition_variable cv;
    std::vector<std::thread> threads;
    bool stop_worker;
    std::thread worker_thread;

    
    std::vector<int> rolling_hash(const std::vector<int>& vec, int window_size);
    bool check_plagiarism_75_length(const std::shared_ptr<submission_t>& new_submission,const std::shared_ptr<submission_t>& existing_submission);
    bool check_plagiarism_for_short_patterns(const std::shared_ptr<submission_t>& new_submission,const std::shared_ptr<submission_t>& existing_submission);
    int check_plagiarism_for_short_patterns_count(std::vector<std::pair<int,int>> &hashed_new_token_pair, std::vector<int>&visisted_new, const std::shared_ptr<submission_t>& existing_submission,std::vector<int> tokens_new);
    void process_submission(const std::shared_ptr<submission_t>& submission,const std::chrono::system_clock::time_point& timestamp);
    void flag_users(const std::shared_ptr<submission_t>& submission);
    void worker_function();

    void lock_and_add(std::shared_ptr<submission_t> submssion, std::chrono::system_clock::time_point timestamo){
        std::lock_guard<std::mutex> lock(submission_queue);
        submissions.emplace(submssion,timestamp);
    }
    // End TODO
};