// // // #include "structures.hpp"
// // // // -----------------------------------------------------------------------------

// // // // You are free to add any STL includes above this comment, below the --line--.
// // // // DO NOT add "using namespace std;" or include any other files/libraries.
// // // // Also DO NOT add the include "bits/stdc++.h"

// // // // OPTIONAL: Add your helper functions and classes here

// // // class plagiarism_checker_t {
// // //     // You should NOT modify the public interface of this class.
// // // public:
// // //     plagiarism_checker_t(void);
// // //     plagiarism_checker_t(std::vector<std::shared_ptr<submission_t>> 
// // //                             __submissions);
// // //     ~plagiarism_checker_t(void);
// // //     void add_submission(std::shared_ptr<submission_t> __submission);

// // // protected:
// // //     // TODO: Add members and function signatures here
    
// // //     // End TODO
// // // }; m



// // #include <iostream>
// // #include <vector>
// // #include <queue>
// // #include <memory>
// // #include <thread>
// // #include <mutex>
// // #include <condition_variable>
// // #include <chrono>
// // #include <atomic>
// // #include <unordered_map>

// // // Forward declaration of tokenizer functionality
// // #include "../tokenizer.hpp"

// // class plagiarism_checker_t {
// // public:
// //     plagiarism_checker_t() : stop_worker(false) {
// //         start_worker();
// //     }

// //     plagiarism_checker_t(std::vector<std::shared_ptr<submission_t>> __submissions)
// //         : submissions(__submissions), stop_worker(false) {
// //         start_worker();
// //     }

// //     ~plagiarism_checker_t() {
// //         {
// //             std::lock_guard<std::mutex> lock(queue_mutex);
// //             stop_worker = true;
// //         }
// //         cv.notify_all();
// //         if (worker_thread.joinable()) {
// //             worker_thread.join();
// //         }
// //     }

// //     void add_submission(std::shared_ptr<submission_t> __submission) {
// //         auto timestamp = std::chrono::system_clock::now();
// //         {
// //             std::lock_guard<std::mutex> lock(queue_mutex);
// //             submission_queue.emplace(__submission, timestamp);
// //         }
// //         cv.notify_all();
// //     }

// // protected:
// //     // Members
// //     std::vector<std::shared_ptr<submission_t>> submissions;  //stores all the existing functions
// //     std::queue<std::pair<std::shared_ptr<submission_t>, std::chrono::system_clock::time_point>> submission_queue;
// //     std::mutex queue_mutex;
// //     std::condition_variable cv;
// //     std::atomic<bool> stop_worker;
// //     std::thread worker_thread;

// //     // Helper function to check plagiarism

// //     // Background worker function
// //     void worker_function() {
// //         while (!stop_worker) {
// //             std::pair<std::shared_ptr<submission_t>, std::chrono::system_clock::time_point> task;
// //             {
// //                 std::unique_lock<std::mutex> lock(queue_mutex);
// //                 cv.wait(lock, [this]() {
// //                     return !submission_queue.empty() || stop_worker;
// //                 });

// //                 if (stop_worker && submission_queue.empty()) {
// //                     break;
// //                 }

// //                 task = submission_queue.front();
// //                 submission_queue.pop();
// //             }

// //             // Process submission
// //             process_submission(task.first, task.second);
// //         }
// //     }

// //     void process_submission(const std::shared_ptr<submission_t>& submission,
// //                             const std::chrono::system_clock::time_point& timestamp) {
// //         for (const auto& existing_submission : submissions) {
// //             // if (check_plagiarism(submission, existing_submission)) {
// //                 // flag_users(submission);
// //                 // break;
// //             // }
// //             if (1) {
// //                 flag_users(submission);
// //                 break;
// //             }
// //         }

// //         // Add to the list of processed submissions
// //         submissions.push_back(submission);
// //     }

// //     void flag_users(const std::shared_ptr<submission_t>& submission) {
// //         if (submission->student) {
// //             submission->student->flag_student(submission);
// //         }
// //         if (submission->professor) {
// //             submission->professor->flag_professor(submission);
// //         }
// //     }

// //     void start_worker() {
// //         worker_thread = std::thread(&plagiarism_checker_t::worker_function, this);
// //     }



    
// // };

// #include "plagiarism_checker.hpp"
// // You should NOT add ANY other includes to this file.
// // Do NOT add "using namespace std;".

// // TODO: Implement the methods of the plagiarism_checker_t class

// // End TODO

// // std::vector<int> rolling_hash(const std::vector<int>& vec, int window_size=75) {
    
// //     const int BASE = 257;       
// //     const int MOD = 1e9 + 7;

// //     std::vector<int> hashed_values;

// //     int b =vec.size();

// //     if (b < window_size) {
// //         return hashed_values; 
// //     }

// //     long long current_hash = 0;
// //     long long base_pow = 1;  

// //     for (int i = 0; i < window_size; i++) {
// //         current_hash = (current_hash * BASE + vec[i]) % MOD;
// //         if (i < window_size - 1) {
// //             base_pow = (base_pow * BASE) % MOD;
// //         }
// //     }
// //     hashed_values.push_back(current_hash);

// //     for (size_t i = window_size; i < vec.size(); ++i) {


// //         current_hash = (current_hash - vec[i - window_size] * base_pow % MOD + MOD) % MOD;

// //         current_hash = (current_hash * BASE + vec[i]) % MOD;

// //         hashed_values.push_back(current_hash);
// //     }

// //     return hashed_values;
// // }



// // // For 75 length exact match 
// // bool check_plagiarism_75_length(const std::shared_ptr<submission_t>& new_submission,
// //                         const std::shared_ptr<submission_t>& existing_submission) {
// //     // Use tokenizer to compare submissions
// //     std::vector<int> tokens_new = tokenize(new_submission->codefile);
// //     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

// //     std::vector<int> hashed_new_token=rolling_hash(tokens_new);
// //     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing);

// //     sort(hashed_new_token.begin(),hashed_new_token.end());
// //     sort(hashed_tokens_existing.begin(),hashed_tokens_existing.end());

// //     int len_new = tokens_new.size();
// //     int len_existing = tokens_existing.size();

// //     int len_new_hashed = hashed_new_token.size();
// //     int len_existing_hashed = hashed_tokens_existing.size();

// //     int i=0;
// //     int j=0;

// //     while(i < len_new_hashed && j < len_existing_hashed ){
// //         int hashed_new_i=hashed_new_token[i];
// //         int hashed_exist_j=hashed_tokens_existing[j];
// //         if(hashed_new_i ==hashed_exist_j){
// //             return true;
// //         }
// //         else if (hashed_new_i < hashed_exist_j){
// //             i++;
// //         }
// //         else{
// //             j++; // when hashed_new_i > hashed_exist_j
// //         }
// //     }
// //     return false;
// // }    

// // bool check_plagiarism_for_short_patterns(const std::shared_ptr<submission_t>& new_submission,
// //                         const std::shared_ptr<submission_t>& existing_submission) {
// //     // Use tokenizer to compare submissions
// //     std::vector<int> tokens_new = tokenize(new_submission->codefile);
// //     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

// //     std::vector<int> hashed_new_token=rolling_hash(tokens_new,15);
// //     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing,15);

// //     std::vector<std::pair<int,int>> hashed_new_token_pair;
// //     std::vector<std::pair<int,int>> hashed_token_existing_pair;

// //     int len_new = tokens_new.size();
// //     int len_existing = tokens_existing.size();

// //     int len_new_hashed = hashed_new_token.size();
// //     int len_existing_hashed = hashed_tokens_existing.size();

// //     for(int i=0 ; i < len_new_hashed ; i++ ){
// //         hashed_new_token_pair.push_back({hashed_new_token[i],i}); // Storing hashed value, index
// //     }
// //     for(int i=0 ; i < len_existing_hashed ; i++ ){
// //         hashed_token_existing_pair.push_back({hashed_tokens_existing[i],i});
// //     }

// //     sort(hashed_new_token_pair.begin(),hashed_new_token_pair.end());
// //     sort(hashed_token_existing_pair.begin(),hashed_token_existing_pair.end());



// //     int i=0;
// //     int j=0;
// //     int count=0;
    
// //     std::vector<int>visisted_new(len_new,0);
// //     std::vector<int>visisted_exist(len_existing,0);

// //     while(i < len_new_hashed && j < len_existing_hashed ){
// //         int hashed_new_i = hashed_new_token_pair[i].first;
// //         int hashed_exist_j = hashed_token_existing_pair[j].first;

// //         int indexactual_new = hashed_new_token_pair[i].second;
// //         int indexactual_exist = hashed_token_existing_pair[j].second;

// //         if(visisted_new[indexactual_new]){
// //             i++;
// //             continue;
// //         }
// //         if(visisted_exist[indexactual_exist]){
// //             j++;
// //             continue;
// //         }

// //         if(hashed_new_i ==hashed_exist_j){
// //             count++;
// //             i++;
// //             j++;
// //             int vislen=0;
// //             while(vislen<15 && indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new){
// //                 visisted_new[indexactual_new+vislen]=1;
// //                 visisted_exist[indexactual_exist+vislen]=1;
// //                 vislen++;
// //             }
// //             while(indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new && tokens_new[indexactual_new + vislen] == tokens_existing [indexactual_exist + vislen]  ){
// //                 visisted_new[indexactual_new+vislen]=1;
// //                 visisted_exist[indexactual_exist+vislen]=1;
// //                 vislen++;               
// //             }
// //         }
// //         else if (hashed_new_i < hashed_exist_j){
// //             i++;
// //         }
// //         else{
// //             j++; // when hashed_new_i > hashed_exist_j
// //         }
// //         if(count >=10){
// //             return true;
// //         }
// //     }
// //     return count>=10;
// // }   

// // // For 75 length exact match 
// // bool check_plagiarism(const std::shared_ptr<submission_t>& new_submission,
// //                         const std::shared_ptr<submission_t>& existing_submission) {
// //     // Use tokenizer to compare submissions
// //     std::vector<int> tokens_new = tokenize(new_submission->codefile);
// //     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

// //     std::vector<int> hashed_new_token=rolling_hash(tokens_new);
// //     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing);

// //     sort(hashed_new_token.begin(),hashed_new_token.end());
// //     sort(hashed_tokens_existing.begin(),hashed_tokens_existing.end());

// //     int len_new = tokens_new.size();
// //     int len_existing = tokens_existing.size();

// //     int i=0;
// //     int j=0;

// //     while(i < len_new && j < len_existing ){
// //         int hashed_new_i=hashed_new_token[i];
// //         int hashed_exist_j=hashed_tokens_existing[j];
// //         if(hashed_new_i ==hashed_exist_j){
// //             return true;
// //         }
// //         else if (hashed_new_i < hashed_exist_j){
// //             i++;
// //         }
// //         else{
// //             j++; // when hashed_new_i > hashed_exist_j
// //         }
// //     }
// //     return false;
// // }    



// // int check_plagiarism_for_short_patterns_count(std::vector<std::pair<int,int>> &hashed_new_token_pair, std::vector<int>&visisted_new, const std::shared_ptr<submission_t>& existing_submission,std::vector<int> tokens_new) {
// //     // // Use tokenizer to compare submissions
// //     // std::vector<int> tokens_new = tokenize(new_submission->codefile);
// //     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

// //     // std::vector<int> hashed_new_token=rolling_hash(tokens_new,15);
// //     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing,15);

// //     // std::vector<std::pair<int,int>> hashed_new_token_pair;
// //     std::vector<std::pair<int,int>> hashed_token_existing_pair;

// //     int len_new = tokens_new.size();
// //     int len_existing = tokens_existing.size();

// //     int len_new_hashed = hashed_new_token_pair.size();
// //     int len_existing_hashed = tokens_existing.size();

// //     // for(int i=0 ; i < len_new ; i++ ){
// //     //     hashed_new_token_pair.push_back({hashed_new_token[i],i}); // Storing hashed value, index
// //     // }
// //     for(int i=0 ; i < len_existing_hashed ; i++ ){
// //         hashed_token_existing_pair.push_back({hashed_tokens_existing[i],i});
// //     }

// //     // sort(hashed_new_token_pair.begin(),hashed_new_token_pair.end());
// //     sort(hashed_token_existing_pair.begin(),hashed_token_existing_pair.end());



// //     int i=0;
// //     int j=0;
// //     int count=0;
    
// //     // std::vector<int>visisted_new(len_new,0);
// //     std::vector<int>visisted_exist(len_existing,0);

// //     while(i < len_new_hashed && j < len_existing_hashed ){
// //         int hashed_new_i = hashed_new_token_pair[i].first;
// //         int hashed_exist_j = hashed_token_existing_pair[j].first;

// //         int indexactual_new = hashed_new_token_pair[i].second;
// //         int indexactual_exist = hashed_token_existing_pair[j].second;

// //         if(visisted_new[indexactual_new]){
// //             i++;
// //             continue;
// //         }
// //         if(visisted_exist[indexactual_exist]){
// //             j++;
// //             continue;
// //         }

// //         if(hashed_new_i ==hashed_exist_j){
// //             count++;
// //             i++;
// //             j++;
// //             int vislen=0;
// //             while(vislen<15 && indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new){
// //                 visisted_new[indexactual_new+vislen]=1;
// //                 visisted_exist[indexactual_exist+vislen]=1;
// //                 vislen++;
// //             }
// //             while(indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new && tokens_new[indexactual_new + vislen] == tokens_existing [indexactual_exist + vislen]  ){
// //                 visisted_new[indexactual_new+vislen]=1;
// //                 visisted_exist[indexactual_exist+vislen]=1;
// //                 vislen++;               
// //             }
// //         }
// //         else if (hashed_new_i < hashed_exist_j){
// //             i++;
// //         }
// //         else{
// //             j++; // when hashed_new_i > hashed_exist_j
// //         }
// //     }
// //     return count;
// // }

// #include "plagiarism_checker.hpp"
// // You should NOT add ANY other includes to this file.
// // Do NOT add "using namespace std;".

// // TODO: Implement the methods of the plagiarism_checker_t class

// // End TODO

// std::vector<int> rolling_hash(const std::vector<int>& vec, int window_size=75) {
    
//     const int BASE = 257;       
//     const int MOD = 1e9 + 7;

//     std::vector<int> hashed_values;

//     int b =vec.size();

//     if (b < window_size) {
//         return hashed_values; 
//     }

//     long long current_hash = 0;
//     long long base_pow = 1;  

//     for (int i = 0; i < window_size; i++) {
//         current_hash = (current_hash * BASE + vec[i]) % MOD;
//         if (i < window_size - 1) {
//             base_pow = (base_pow * BASE) % MOD;
//         }
//     }
//     hashed_values.push_back(current_hash);

//     for (size_t i = window_size; i < vec.size(); ++i) {


//         current_hash = (current_hash - vec[i - window_size] * base_pow % MOD + MOD) % MOD;

//         current_hash = (current_hash * BASE + vec[i]) % MOD;

//         hashed_values.push_back(current_hash);
//     }

//     return hashed_values;
// }



// // For 75 length exact match 
// bool check_plagiarism_75_length(const std::shared_ptr<submission_t>& new_submission,
//                         const std::shared_ptr<submission_t>& existing_submission) {
//     // Use tokenizer to compare submissions
//     std::vector<int> tokens_new = tokenize(new_submission->codefile);
//     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

//     std::vector<int> hashed_new_token=rolling_hash(tokens_new);
//     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing);

//     sort(hashed_new_token.begin(),hashed_new_token.end());
//     sort(hashed_tokens_existing.begin(),hashed_tokens_existing.end());

//     int len_new = tokens_new.size();
//     int len_existing = tokens_existing.size();

//     int len_new_hashed = hashed_new_token.size();
//     int len_existing_hashed = hashed_tokens_existing.size();

//     int i=0;
//     int j=0;

//     while(i < len_new_hashed && j < len_existing_hashed ){
//         int hashed_new_i=hashed_new_token[i];
//         int hashed_exist_j=hashed_tokens_existing[j];
//         if(hashed_new_i ==hashed_exist_j){
//             return true;
//         }
//         else if (hashed_new_i < hashed_exist_j){
//             i++;
//         }
//         else{
//             j++; // when hashed_new_i > hashed_exist_j
//         }
//     }
//     return false;
// }    

// bool check_plagiarism_for_short_patterns(const std::shared_ptr<submission_t>& new_submission,
//                         const std::shared_ptr<submission_t>& existing_submission) {
//     // Use tokenizer to compare submissions
//     std::vector<int> tokens_new = tokenize(new_submission->codefile);
//     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

//     std::vector<int> hashed_new_token=rolling_hash(tokens_new,15);
//     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing,15);

//     std::vector<std::pair<int,int>> hashed_new_token_pair;
//     std::vector<std::pair<int,int>> hashed_token_existing_pair;

//     int len_new = tokens_new.size();
//     int len_existing = tokens_existing.size();

//     int len_new_hashed = hashed_new_token.size();
//     int len_existing_hashed = hashed_tokens_existing.size();

//     for(int i=0 ; i < len_new_hashed ; i++ ){
//         hashed_new_token_pair.push_back({hashed_new_token[i],i}); // Storing hashed value, index
//     }
//     for(int i=0 ; i < len_existing_hashed ; i++ ){
//         hashed_token_existing_pair.push_back({hashed_tokens_existing[i],i});
//     }

//     sort(hashed_new_token_pair.begin(),hashed_new_token_pair.end());
//     sort(hashed_token_existing_pair.begin(),hashed_token_existing_pair.end());



//     int i=0;
//     int j=0;
//     int count=0;
    
//     std::vector<int>visisted_new(len_new,0);
//     std::vector<int>visisted_exist(len_existing,0);

//     while(i < len_new_hashed && j < len_existing_hashed ){
//         int hashed_new_i = hashed_new_token_pair[i].first;
//         int hashed_exist_j = hashed_token_existing_pair[j].first;

//         int indexactual_new = hashed_new_token_pair[i].second;
//         int indexactual_exist = hashed_token_existing_pair[j].second;

//         if(visisted_new[indexactual_new]){
//             i++;
//             continue;
//         }
//         if(visisted_exist[indexactual_exist]){
//             j++;
//             continue;
//         }

//         if(hashed_new_i ==hashed_exist_j){
//             count++;
//             i++;
//             j++;
//             int vislen=0;
//             while(vislen<15 && indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new){
//                 visisted_new[indexactual_new+vislen]=1;
//                 visisted_exist[indexactual_exist+vislen]=1;
//                 vislen++;
//             }
//             while(indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new && tokens_new[indexactual_new + vislen] == tokens_existing [indexactual_exist + vislen]  ){
//                 visisted_new[indexactual_new+vislen]=1;
//                 visisted_exist[indexactual_exist+vislen]=1;
//                 vislen++;               
//             }
//             vislen=0;
//             while(indexactual_exist +vislen >=0  && indexactual_new + vislen >=0 && tokens_new[indexactual_new +vislen ] == tokens_existing [indexactual_exist + vislen]  ){
//                 visisted_new[indexactual_new+vislen]=1;
//                 visisted_exist[indexactual_exist+vislen]=1;
//                 vislen--;               
//             }
//         }
//         else if (hashed_new_i < hashed_exist_j){
//             i++;
//         }
//         else{
//             j++; // when hashed_new_i > hashed_exist_j
//         }
//         if(count >=10){
//             return true;
//         }
//     }
//     return count>=10;
// }   

// // For 75 length exact match 
// bool check_plagiarism(const std::shared_ptr<submission_t>& new_submission,
//                         const std::shared_ptr<submission_t>& existing_submission) {
//     // Use tokenizer to compare submissions
//     std::vector<int> tokens_new = tokenize(new_submission->codefile);
//     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

//     std::vector<int> hashed_new_token=rolling_hash(tokens_new);
//     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing);

//     sort(hashed_new_token.begin(),hashed_new_token.end());
//     sort(hashed_tokens_existing.begin(),hashed_tokens_existing.end());

//     int len_new = tokens_new.size();
//     int len_existing = tokens_existing.size();

//     int i=0;
//     int j=0;

//     while(i < len_new && j < len_existing ){
//         int hashed_new_i=hashed_new_token[i];
//         int hashed_exist_j=hashed_tokens_existing[j];
//         if(hashed_new_i ==hashed_exist_j){
//             return true;
//         }
//         else if (hashed_new_i < hashed_exist_j){
//             i++;
//         }
//         else{
//             j++; // when hashed_new_i > hashed_exist_j
//         }
//     }
//     return false;
// }    



// int check_plagiarism_for_short_patterns_count(std::vector<std::pair<int,int>> &hashed_new_token_pair, std::vector<int>&visisted_new, const std::shared_ptr<submission_t>& existing_submission,std::vector<int> tokens_new) {
//     // // Use tokenizer to compare submissions
//     // std::vector<int> tokens_new = tokenize(new_submission->codefile);
//     std::vector<int> tokens_existing = tokenize(existing_submission->codefile);

//     // std::vector<int> hashed_new_token=rolling_hash(tokens_new,15);
//     std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing,15);

//     // std::vector<std::pair<int,int>> hashed_new_token_pair;
//     std::vector<std::pair<int,int>> hashed_token_existing_pair;

//     int len_new = tokens_new.size();
//     int len_existing = tokens_existing.size();

//     int len_new_hashed = hashed_new_token_pair.size();
//     int len_existing_hashed = tokens_existing.size();

//     // for(int i=0 ; i < len_new ; i++ ){
//     //     hashed_new_token_pair.push_back({hashed_new_token[i],i}); // Storing hashed value, index
//     // }
//     for(int i=0 ; i < len_existing_hashed ; i++ ){
//         hashed_token_existing_pair.push_back({hashed_tokens_existing[i],i});
//     }

//     // sort(hashed_new_token_pair.begin(),hashed_new_token_pair.end());
//     sort(hashed_token_existing_pair.begin(),hashed_token_existing_pair.end());



//     int i=0;
//     int j=0;
//     int count=0;
    
//     // std::vector<int>visisted_new(len_new,0);
//     std::vector<int>visisted_exist(len_existing,0);

//     while(i < len_new_hashed && j < len_existing_hashed ){
//         int hashed_new_i = hashed_new_token_pair[i].first;
//         int hashed_exist_j = hashed_token_existing_pair[j].first;

//         int indexactual_new = hashed_new_token_pair[i].second;
//         int indexactual_exist = hashed_token_existing_pair[j].second;

//         if(visisted_new[indexactual_new]){
//             i++;
//             continue;
//         }
//         if(visisted_exist[indexactual_exist]){
//             j++;
//             continue;
//         }

//         if(hashed_new_i ==hashed_exist_j){
//             count++;
//             i++;
//             j++;
//             int vislen=0;
//             while(vislen<15 && indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new){
//                 visisted_new[indexactual_new+vislen]=1;
//                 visisted_exist[indexactual_exist+vislen]=1;
//                 vislen++;
//             }
//             while(indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new && tokens_new[indexactual_new + vislen] == tokens_existing [indexactual_exist + vislen]  ){
//                 visisted_new[indexactual_new+vislen]=1;
//                 visisted_exist[indexactual_exist+vislen]=1;
//                 vislen++;               
//             }
//             vislen=0;
//             while(indexactual_exist +vislen >=0  && indexactual_new + vislen >=0 && tokens_new[indexactual_new +vislen ] == tokens_existing [indexactual_exist + vislen]  ){
//                 visisted_new[indexactual_new+vislen]=1;
//                 visisted_exist[indexactual_exist+vislen]=1;
//                 vislen--;               
//             }
//         }
//         else if (hashed_new_i < hashed_exist_j){
//             i++;
//         }
//         else{
//             j++; // when hashed_new_i > hashed_exist_j
//         }
//     }
//     return count;
// }


    void process_submission(const std::shared_ptr<submission_t>& submission,const std::chrono::system_clock::time_point& timestamp) {
        for (const auto& e : submissions) {
            auto existing_submission = e.first;
            auto time_of_arrival = e.second;
        //     if (abs(timestamp-seconds(time_of_arrival))>=1) {
        //         flag_users(submission);
        //         break;
        //     }
        // //     if (true) {
        // //         // if(abs())
        // //         flag_users(submission);
        // //         break;
        // //     }
        // }
        //************* */
        auto submission_time_in_seconds = 
            std::chrono::duration_cast<std::chrono::seconds>(timestamp.time_since_epoch()).count();

        auto arrival_time_in_seconds = 
            std::chrono::duration_cast<std::chrono::seconds>(time_of_arrival.time_since_epoch()).count();

        // Check if the absolute time difference is greater than or equal to 1 second
        if (std::abs(submission_time_in_seconds - arrival_time_in_seconds) >= 1) {
            flag_users(submission);
            break;
        }
        }
        // flag_users(submission);

        // Add to the list of processed submissions
        submissions.push_back({submission,timestamp});
    }