#include "plagiarism_checker.hpp"
// You should NOT add ANY other includes to this file.
// Do NOT add "using namespace std;".

// TODO: Implement the methods of the plagiarism_checker_t class

//constructor for plagiarism_checker_t class without initializing the submission vector
plagiarism_checker_t::plagiarism_checker_t(size_t num_threads) : stop_worker(false) {
    for (size_t i = 0; i < num_threads; ++i) {
        threads.emplace_back(&plagiarism_checker_t::worker_function, this);
    }
}
////constructor for plagiarism_checker_t class with initializing the submission vector
plagiarism_checker_t::plagiarism_checker_t(std::vector<std::shared_ptr<submission_t>> __submissions, size_t num_threads)
    : plagiarism_checker_t(num_threads) {
    auto now = std::chrono::system_clock::now();
    for (const auto& submission : __submissions) {
        submissions.emplace_back(submission, now);
    }
}
//destructor for plagiarism_checker_t class
plagiarism_checker_t::~plagiarism_checker_t() {
    stop_worker = true; 
    cv.notify_all();   
    for (auto& thread : threads) {
        if (thread.joinable()) {
            thread.join();
        }
    }

}

//this takes a shared ptr and add this to the vector submissions
void plagiarism_checker_t::add_submission(std::shared_ptr<submission_t> __submission) {
    auto timestamp = std::chrono::system_clock::now();
    {
        std::lock_guard<std::mutex> lock(queue_mutex);
        submission_queue.emplace(__submission, timestamp);
    }
    cv.notify_all();
}

//this function takes submission and flags the corresponding student and prof
void plagiarism_checker_t::flag_users(const std::shared_ptr<submission_t>& submission) {
        if (submission->student) {
            submission->student->flag_student(submission);
        }
        if (submission->professor) {
            submission->professor->flag_professor(submission);
        }
}

//this function runs on the thread of each submission entry
void plagiarism_checker_t::worker_function() {
        while (!stop_worker) {
            std::pair<std::shared_ptr<submission_t>, std::chrono::system_clock::time_point> task;

            {
                std::unique_lock<std::mutex> lock(queue_mutex);

                //wait for new tasks or stop signal
                cv.wait(lock, [this]() {
                    return !submission_queue.empty() || stop_worker;
                });
                
                //exit thread
                if (stop_worker && submission_queue.empty()) {
                    return;
                }

                //dequeue task
                task = submission_queue.front();
                submission_queue.pop();
            }

            //process the dequeued submission
            process_submission(task.first, task.second);
        }
}

//plag check wale

std::vector<int> plagiarism_checker_t::rolling_hash(const std::vector<int>& vec, int window_size=75) {
    
    const int BASE = 257;       
    const int MOD = 1e9 + 7;

    std::vector<int> hashed_values;

    int b =vec.size();

    if (b < window_size) {
        return hashed_values; 
    }

    long long current_hash = 0;
    long long base_pow = 1;  

    for (int i = 0; i < window_size; i++) {
        current_hash = (current_hash * BASE + vec[i]) % MOD;
        if (i < window_size - 1) {
            base_pow = (base_pow * BASE) % MOD;
        }
    }
    hashed_values.push_back(current_hash);

    for (size_t i = window_size; i < vec.size(); ++i) {


        current_hash = (current_hash - vec[i - window_size] * base_pow % MOD + MOD) % MOD;

        current_hash = (current_hash * BASE + vec[i]) % MOD;

        hashed_values.push_back(current_hash);
    }

    return hashed_values;
}



// For 75 length exact match 
bool plagiarism_checker_t::check_plagiarism_75_length(const std::shared_ptr<submission_t>& new_submission,const std::shared_ptr<submission_t>& existing_submission) {
    // Use tokenizer to compare submissions
    tokenizer_t t1(new_submission->codefile);
    tokenizer_t t2(existing_submission->codefile);

    std::vector<int> tokens_new = t1.get_tokens();
    std::vector<int> tokens_existing = t2.get_tokens();

    // Using hash to get exact match of 75
    std::vector<int> hashed_new_token=rolling_hash(tokens_new);
    std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing);

    // Sorting the hashed vakues so that it could be compared easily with two pointers
    sort(hashed_new_token.begin(),hashed_new_token.end());
    sort(hashed_tokens_existing.begin(),hashed_tokens_existing.end());

    int len_new = tokens_new.size();
    int len_existing = tokens_existing.size();

    int len_new_hashed = hashed_new_token.size();
    int len_existing_hashed = hashed_tokens_existing.size();

    // Initialising the two pointers
    int i=0;
    int j=0;

    // Find the exact match of 75 length in the loop 
    while(i < len_new_hashed && j < len_existing_hashed ){
        int hashed_new_i=hashed_new_token[i];
        int hashed_exist_j=hashed_tokens_existing[j];
        if(hashed_new_i ==hashed_exist_j){
            return true;
        }
        else if (hashed_new_i < hashed_exist_j){
            i++;
        }
        else{
            j++; // when hashed_new_i > hashed_exist_j
        }
    }
    return false;
}    


// This function returns true if there is atleast 10 matching patterns of length approx 15 , else false
bool plagiarism_checker_t::check_plagiarism_for_short_patterns(const std::shared_ptr<submission_t>& new_submission,const std::shared_ptr<submission_t>& existing_submission) {
    // Use tokenizer to compare submissions
    
    tokenizer_t t1(new_submission->codefile);
    tokenizer_t t2(existing_submission->codefile);
    std::vector<int> tokens_new = t1.get_tokens();
    std::vector<int> tokens_existing = t2.get_tokens();

    std::vector<int> hashed_new_token=rolling_hash(tokens_new,15);
    std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing,15);

    std::vector<std::pair<int,int>> hashed_new_token_pair;
    std::vector<std::pair<int,int>> hashed_token_existing_pair;

    int len_new = tokens_new.size();
    int len_existing = tokens_existing.size();

    int len_new_hashed = hashed_new_token.size();
    int len_existing_hashed = hashed_tokens_existing.size();

    for(int i=0 ; i < len_new_hashed ; i++ ){
        hashed_new_token_pair.push_back({hashed_new_token[i],i}); // Storing hashed value, index
    }
    for(int i=0 ; i < len_existing_hashed ; i++ ){
        hashed_token_existing_pair.push_back({hashed_tokens_existing[i],i});
    }

    sort(hashed_new_token_pair.begin(),hashed_new_token_pair.end());
    sort(hashed_token_existing_pair.begin(),hashed_token_existing_pair.end());



    int i=0;
    int j=0;
    int count=0;
    
    std::vector<int>visisted_new(len_new,0);
    std::vector<int>visisted_exist(len_existing,0);

    while(i < len_new_hashed && j < len_existing_hashed ){
        int hashed_new_i = hashed_new_token_pair[i].first;
        int hashed_exist_j = hashed_token_existing_pair[j].first;

        int indexactual_new = hashed_new_token_pair[i].second;
        int indexactual_exist = hashed_token_existing_pair[j].second;

        if(visisted_new[indexactual_new]){
            i++;
            continue;
        }
        if(visisted_exist[indexactual_exist]){
            j++;
            continue;
        }

        if(hashed_new_i ==hashed_exist_j){
            count++;
            i++;
            j++;
            int vislen=0;
            // Marking visited such that , It will not be visited in future 
            while(vislen<15 && indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new){
                visisted_new[indexactual_new+vislen]=1;
                visisted_exist[indexactual_exist+vislen]=1;
                vislen++;
            }
        }
        else if (hashed_new_i < hashed_exist_j){
            i++;
        }
        else{
            j++;
        }
        if(count >=10){
            return true;
        }
    }
    return count>=10;
}   

// this returns number of short length matching that was not previously matched
int plagiarism_checker_t::check_plagiarism_for_short_patterns_count(std::vector<std::pair<int,int>> &hashed_new_token_pair, std::vector<int>&visisted_new, const std::shared_ptr<submission_t>& existing_submission,std::vector<int> tokens_new) {
    tokenizer_t t2(existing_submission->codefile);
    std::vector<int> tokens_existing = t2.get_tokens();

    std::vector<int> hashed_tokens_existing=rolling_hash(tokens_existing,15);

    std::vector<std::pair<int,int>> hashed_token_existing_pair;

    int len_new = tokens_new.size();
    int len_existing = tokens_existing.size();

    int len_new_hashed = hashed_new_token_pair.size();
    int len_existing_hashed = hashed_tokens_existing.size();

    // assert(len_existing_hashed == hashed_tokens_existing.size());
    for(int i=0 ; i < len_existing_hashed ; i++ ){
        hashed_token_existing_pair.push_back({hashed_tokens_existing[i],i});
    }

    sort(hashed_token_existing_pair.begin(),hashed_token_existing_pair.end());

    int i=0;
    int j=0;
    int count=0;
    
    std::vector<int>visisted_exist(len_existing,0);

    while(i < len_new_hashed && j < len_existing_hashed ){
        int hashed_new_i = hashed_new_token_pair[i].first;
        int hashed_exist_j = hashed_token_existing_pair[j].first;

        int indexactual_new = hashed_new_token_pair[i].second;
        int indexactual_exist = hashed_token_existing_pair[j].second;

        if(visisted_new[indexactual_new]){
            i++;
            continue;
        }
        if(visisted_exist[indexactual_exist]){
            j++;
            continue;
        }

        if(hashed_new_i ==hashed_exist_j){
            count++;
            i++;
            j++;
            int vislen=0;
            while(vislen<15 && indexactual_exist +vislen < len_existing && indexactual_new + vislen < len_new){
                visisted_new[indexactual_new+vislen]=1;
                visisted_exist[indexactual_exist+vislen]=1;
                vislen++;
            }
        }
        else if (hashed_new_i < hashed_exist_j){
            i++;
        }
        else{
            j++;
        }
    }
    return count;
}
//***************/
//this function takes a submission from the submission vector and process it 
void plagiarism_checker_t::plagiarism_checker_t::process_submission(const std::shared_ptr<submission_t>& submission,const std::chrono::system_clock::time_point& timestamp) {
    
    // {
    //     std::lock_guard<std::mutex> lock(submission_mutex);
    //     submissions.emplace_back(submission, timestamp);
    // }

    int i = 0;

    while (true) {
        std::shared_ptr<submission_t> existing_submission = nullptr;
        std::chrono::system_clock::time_point time_of_arrival;

        {
            std::lock_guard<std::mutex> lock(submission_mutex);

            if (i < submissions.size()) {
                existing_submission = submissions[i].first;
                time_of_arrival = submissions[i].second;
            } 
            else {
                // submissions.emplace_back(submission, timestamp);
                return;
            }
        }

        auto submission_time_in_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            timestamp.time_since_epoch()).count();
        auto arrival_time_in_ms = std::chrono::duration_cast<std::chrono::milliseconds>(
            time_of_arrival.time_since_epoch()).count();
        if (submission_time_in_ms <= arrival_time_in_ms) {
            // std::lock_guard<std::mutex> lock(submission_mutex);
            // submissions.emplace_back(submission, timestamp);
            return;
        }

        //75% match length
        if (check_plagiarism_75_length(submission, existing_submission)) {
            if (std::abs(submission_time_in_ms - arrival_time_in_ms) <= 1500) {
                flag_users(existing_submission);
            }
            flag_users(submission);
            // std::lock_guard<std::mutex> lock(submission_mutex);
            // submissions.emplace_back(submission, timestamp);
            return;
        }

        //short patterns
        if (check_plagiarism_for_short_patterns(submission, existing_submission)) {
            if (std::abs(submission_time_in_ms - arrival_time_in_ms) <= 1500) {
                flag_users(existing_submission);
            }
            flag_users(submission);
            // std::lock_guard<std::mutex> lock(submission_mutex);
            // submissions.emplace_back(submission, timestamp);
            return;
        }

        int count_short_patterns = 0;
        tokenizer_t t1(submission->codefile);
        std::vector<int> tokens_new = t1.get_tokens();
        std::vector<int> hashed_new_token = rolling_hash(tokens_new, 15);
        std::vector<std::pair<int, int>> hashed_new_token_pair;

        for (size_t j = 0; j < hashed_new_token.size(); ++j) {
            hashed_new_token_pair.emplace_back(hashed_new_token[j], j);
        }

        std::sort(hashed_new_token_pair.begin(), hashed_new_token_pair.end());
        std::vector<int> visited_new(tokens_new.size(), 0);
        count_short_patterns += check_plagiarism_for_short_patterns_count(
            hashed_new_token_pair, visited_new, existing_submission, tokens_new);

        if (count_short_patterns >= 20) {
            if (std::abs(submission_time_in_ms - arrival_time_in_ms) <= 1500) {
                flag_users(existing_submission);
            }
            flag_users(submission);
            // std::lock_guard<std::mutex> lock(submission_mutex);
            // submissions.emplace_back(submission, timestamp);
            return;
        }
        i++;
    }

    //add to the submissions vector after locking submission mutex
    // {
        // std::lock_guard<std::mutex> lock(submission_mutex);
        // submissions.emplace_back(submission, timestamp);
    // }

    // {
    //     std::lock_guard<std::mutex> lock(submission_mutex);
    //     submissions.emplace(submission,timestamp);
    // }

    lock_and_add(submssion,timestamp);
}
// End TODO