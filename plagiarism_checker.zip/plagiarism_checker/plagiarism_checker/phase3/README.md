# Phase 3 Plagiarism Checker

We have provided the plagiarism checkers for you. Copy-paste any files from phase 1 to use them.
The plagiarism checkers include those of teams:
- Solution (sample, by us TAs)
- Team 23B0999\_23B1006
- Team 23b0924\_23b1032\_23b1055
- Team 23B0946\_23B0918\_23B1002
- Team 23B1001\_23B1024\_23B1071
- Team 23b0940\_23b1029\_23b0903
